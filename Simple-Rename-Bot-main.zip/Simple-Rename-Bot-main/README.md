# Simple-Rename-Bot 

📝 Simple & High Speed Telegram File Rename Bot For only personal use 


## How To Deploy

<a href="https://youtu.be/oc847WvOUaI"><img src="https://img.shields.io/badge/Watch%20Tutorial%20On%20YouTube-red.svg?logo=Youtube"></a>                     

## Deployment Support


## Deploy to Koyeb

⚠️ personal use & 1 process at a time 

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?type=git&repository=github.com/MrMKN/Simple-Rename-Bot&env[BOT_TOKEN]&env[API_ID]&env[API_HASH]&env[ADMIN]&env[CAPTION]&env[THUMBNAIL]&run_command=python%20bot.py&branch=main&name=renamer)              

### Heroku

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/MrMKN/Simple-Rename-Bot)

## BotFather Command
```
start - get start the bot
rename - replay with file to rename
del - to delete your thumbnail 
view - view current thumbnail 
```


## Support

● [BOT UPDATES](https://t.me/mkn_bots_updates)

● [SUPPORT GROUP](https://t.me/mkn_botz_discussion_group)
